---
name: Cybernetic Kinetic HUD
colors:
  surface: '#0c1324'
  surface-dim: '#0c1324'
  surface-bright: '#33394c'
  surface-container-lowest: '#070d1f'
  surface-container-low: '#151b2d'
  surface-container: '#191f31'
  surface-container-high: '#23293c'
  surface-container-highest: '#2e3447'
  on-surface: '#dce1fb'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#dce1fb'
  inverse-on-surface: '#2a3043'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#2fd9f4'
  on-tertiary: '#00363e'
  tertiary-container: '#00b7cf'
  on-tertiary-container: '#00434d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#a2eeff'
  tertiary-fixed-dim: '#2fd9f4'
  on-tertiary-fixed: '#001f25'
  on-tertiary-fixed-variant: '#004e5a'
  background: '#0c1324'
  on-background: '#dce1fb'
  surface-variant: '#2e3447'
typography:
  display:
    fontFamily: spaceGrotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: spaceGrotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: spaceGrotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: spaceGrotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: spaceGrotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: spaceGrotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  telemetry-mono:
    fontFamily: spaceMono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-caps:
    fontFamily: spaceMono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.15em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  hud-gap-xs: 0.25rem
  hud-gap-sm: 0.5rem
  hud-gap-md: 1rem
  hud-gap-lg: 1.5rem
  hud-gap-xl: 2.5rem
  layout-margin-mobile: 1.25rem
  layout-margin-desktop: 3rem
  container-max: 80rem
---

## Brand & Style

This design system targets developers, competitive web-gamers, and creative technologists interacting with browser-based computer vision. The visual language evokes precision telemetry, spatial computing, and frictionless kinetic control. 

The aesthetic merges **Glassmorphism** with **Futuristic High-Tech HUD (Heads-Up Display)** conventions:
- **Atmosphere:** Deep void space illuminated by tactical laser optics, chromatic diffusion, and low-latency digital feedback.
- **Form Follows Telemetry:** UI panels feel like spatial glass viewports suspended in front of the user’s camera feed, reacting dynamically to hand tracking and physical gestures.
- **Visual Tension:** Surgical, micro-metric geometric layouts paired with high-voltage neon energy fields and soft luminescent glows.

## Colors

The palette operates strictly within high-contrast night-vision paradigms, balancing deep optical black/slate voids against radiant photons.

- **Void Surfaces (Neutrals):**
  - Canvas Base: `#020617` (Deep Obsidian Slate)
  - Surface Glass: `rgba(15, 23, 42, 0.65)` (Translucent Navy Glass)
  - Elevated HUD Panels: `rgba(30, 41, 59, 0.45)` (Optical Overlay)
  - Edge Borders: `rgba(255, 255, 255, 0.08)` to `rgba(34, 211, 238, 0.25)`

- **Photonic Accents:**
  - Primary Electric Cyan (`#06b6d4` / `#22d3ee`): Signals interactive states, active hand landmarks, primary CTAs, and active nodes.
  - Secondary Deep Neon Blue (`#3b82f6` / `#2563eb`): Structural glows, depth gradients, and secondary telemetry data.
  - Signal Alert / Landmark Warning: `#f43f5e` (Crimson Laser) for tracking loss or out-of-frame boundary states.
  - Calibration Green: `#10b981` (Sensor Lock) for tracking stabilization and hand detection confirmation.

Use subtle linear gradients running at 135 degrees from `#22d3ee` to `#3b82f6` exclusively on accent dividers, primary action surfaces, and active tracking bounding boxes.

## Typography

The typographic hierarchy separates futuristic display styling from clinical developer instrumentation:

- **Headlines (`spaceGrotesk`):** High-tension, geometric letterforms engineered for impactful, forward-leaning positioning. Display sizes utilize tight tracking to generate a compressed cinematic presence.
- **Running Copy (`geist`):** Neutral, hyper-legible sans-serif to render dense hardware specifications, installation instructions, and contextual game guides with high visual clarity on dark backdrops.
- **HUD & Telemetry (`spaceMono`):** Monospaced, capitalized, wide-tracked metrics dedicated to frame rates, joint coordinate vectors `(X, Y, Z)`, latency figures, and technical status badges.

## Layout & Spacing

The layout is built upon a 12-column adaptive grid contained within a maximum width of `80rem` (`1280px`), flanked by contextual telemetry brackets.

- **Desktop (1024px+):** 12 columns with `1.5rem` (`24px`) gutters and `3rem` outer frame margins. UI panels align strictly to modular vertical coordinate lines reminiscent of targeting grids.
- **Tablet (768px - 1023px):** 8 columns with `1rem` (`16px`) gutters and `2rem` screen margin.
- **Mobile (<768px):** 4 columns with `0.75rem` (`12px`) gutters and `1.25rem` screen margins. Hand-tracking camera overlays collapse into responsive bottom drawers with persistent tracking health indicators.

Vertical rhythm relies on baseline increments of `8px` (`0.5rem`). Dense HUD clusters (status indicators, sensor readouts) compress down to `4px` (`0.25rem`) intervals to maintain the dense instrumentation feel of an interactive cockpit.

## Elevation & Depth

Spatial layering relies on glassmorphic refraction, edge luminosity, and photon diffusion rather than traditional drop shadows.

1. **Layer 0 (Canvas Void):** `#020617` saturated with dynamic, ambient radial gradients of deep cyan (`rgba(6, 182, 212, 0.08)`) and electric cobalt (`rgba(59, 130, 246, 0.08)`) positioned beneath key focus areas.
2. **Layer 1 (Frosted Visor Panels):** `rgba(15, 23, 42, 0.65)` background with `16px` to `24px` backdrop-filter blur, enclosed by a hairline boundary: `1px solid rgba(255, 255, 255, 0.1)`.
3. **Layer 2 (Active Target / Floating Hud):** `rgba(30, 41, 59, 0.8)` background with `1px solid rgba(34, 211, 238, 0.4)` border. Neon edge bloom: `box-shadow: 0 0 20px -3px rgba(6, 182, 212, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.2)`.
4. **Layer 3 (Modal / Real-Time Tracking Pointer):** Solid photon presence with zero blur on the stroke: `0 0 30px rgba(34, 211, 238, 0.6)`. Landmarks cast precise dual-layer glows (`0 0 8px #22d3ee`, `0 0 24px #3b82f6`).

## Shapes

The design system employs **Soft Geometric Precision** (`roundedness: 1`). 

- **Base Radius:** `0.25rem` (`4px`) on sub-elements, chips, and micro-badges to preserve a technical, calibrated edge.
- **Panels & Containers:** `0.5rem` (`8px`) on interactive cards and viewport frames (`rounded-lg`).
- **Accent Clipping:** Tactical panels, CTA corners, and targeting reticles may utilize subtle 45-degree chamfered edges (`clip-path: polygon(...)`) to intensify the cybernetic aesthetic.

## Components

### Buttons & Kinetic Triggers
- **Primary Cyber Action:** High-saturation gradient fill (`linear-gradient(135deg, #06b6d4, #2563eb)`), dark text `#020617` with font weight 700. Glow shadow: `0 0 20px rgba(6, 182, 212, 0.4)`. Hover expands glow to `28px` with a subtle scale transform (`1.02`).
- **Ghost HUD Button:** Transparent background, `1px` border in `rgba(34, 211, 238, 0.4)`, text in `#22d3ee`. Hover triggers solid background tint `rgba(6, 182, 212, 0.1)` and corner accent brackets.
- **Pinch-to-Select State:** Progress stroke around the button circumference that fills proportionally as the user maintains a hand pinch gesture.

### Telemetry Cards & Viewports
- Constructed with `backdrop-blur-md`, `bg-slate-950/60`, and `border border-white/10`.
- Top-right corner includes monospaced hardware readouts (e.g., `LATENCY: 12MS`, `FPS: 60`).
- Accent variations incorporate a `2px` horizontal glowing cyan beam along the top edge.

### Chips & Sensor Badges
- Compact capsules with `label-caps` typography.
- Status dot (`6px` circle) featuring an active radar ping animation (`box-shadow` pulse).
- Border: `1px solid rgba(255, 255, 255, 0.15)`.

### Inputs & Camera Calibration Selectors
- Background: `rgba(2, 6, 23, 0.8)`.
- Border: `1px solid rgba(255, 255, 255, 0.15)`.
- Focus state: Border transitions to `#22d3ee` accompanied by an inner cyan glow (`inset 0 0 8px rgba(34, 211, 238, 0.2)`). Monospaced field labels sit outside the box in uppercase with tracking metadata.

### Specialized Platform Components
- **Gesture Landmark HUD:** Overlaid SVG skeleton mesh tracking 21 key points. Points render as `#22d3ee` nodes (`4px`) connected by luminous cyan-to-blue gradient vectors (`1.5px` stroke with `drop-shadow(0 0 4px #06b6d4)`).
- **Latency & FPS Radar Widget:** Monospaced real-time sparkline graph rendered in deep neon blue with glowing cyan peaks, enclosed within a glass panel.
- **Gesture Calibration Target:** Concentric rotating dashed reticles displaying distance calibration messages (`ALIGN PALM`, `DEPTH OK`).